from flask import Flask  # 导入flask模块的Flask类,多个模块
from flask import render_template, request

app = Flask(__name__) # 创建一个Flask类型的对象，把它赋给app变量

@app.route('/')# 引用一个修饰符route

@app.route('/entry')
def entry_page() ->'html':
    return render_template('entry.html',
                            the_title='Welcome to color selection on the web!')

@app.route('/pick_a_color',methods=['POST'])  # 第二个修饰符route
def pick_a_color() -> 'html':
    the_color1 = request.form['user_color1']
    the_color2 = request.form['user_color2'] #创建新的变量，并赋值
    title = 'Look!The color were changed!'
    return render_template('results.html',
                           the_title=title,
                           the_color1=the_color1,
                           the_color2=the_color2,
                           color1=the_color1,
                           color2=the_color2,)


if __name__ == '__main__':
    app.run()